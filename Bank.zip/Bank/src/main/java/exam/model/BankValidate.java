package exam.model;

public class BankValidate {

	public static boolean isValid(BankSystem currBank)
	{
		boolean success=false;
		
		String currentName=currBank.getHoldername();
		String currentAccNo=currBank.getAccNo();
		
		if(currentName.equals("Rushikesh") && currentAccNo.equals("SBI9299"))
			success=true;
		
		return success;
		
	}
}
