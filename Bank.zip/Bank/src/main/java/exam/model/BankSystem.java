package exam.model;

import java.util.Objects;

public class BankSystem {

	private String Holdername;
	private String accNo;
	private float balance;
	public BankSystem() {
		// TODO Auto-generated constructor stub
	}
	public BankSystem(String holdername, String accNo, float balance) {
		super();
		Holdername = holdername;
		this.accNo = accNo;
		this.balance = balance;
	}
	public String getHoldername() {
		return Holdername;
	}
	public void setHoldername(String holdername) {
		Holdername = holdername;
	}
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "BankSystem [Holdername=" + Holdername + ", accNo=" + accNo + ", balance=" + balance + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(Holdername, accNo, balance);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankSystem other = (BankSystem) obj;
		return Objects.equals(Holdername, other.Holdername) && Objects.equals(accNo, other.accNo)
				&& Float.floatToIntBits(balance) == Float.floatToIntBits(other.balance);
	}
	

	
}
