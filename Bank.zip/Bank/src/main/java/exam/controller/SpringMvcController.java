package exam.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import exam.model.BankSystem;
import exam.model.BankValidate;


@Controller
public class SpringMvcController {

	@RequestMapping("/HomePage")
	public String getIndexPage()
	{
		return "index";
	}
	
	@RequestMapping("/showLogin")
	public String getLoginPage()
	{
		return "login";
	}
	
	@RequestMapping(value="/dovalidate",method = RequestMethod.POST)
	public String getResultPage(String accno,String name,int ibal)
	{
		String resultPage="failure";
		BankSystem bank=new BankSystem(name, accno, ibal);
		boolean success=BankValidate.isValid(bank);
		if(success)
			resultPage="success";
		return resultPage;
	}
}
